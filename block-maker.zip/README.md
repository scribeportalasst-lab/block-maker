# Block Maker
A touch-first level maker for Android. Two maps, 15 parts, build then play.

## Get the APK
1. Push this repo to GitHub (branch `main`).
2. Open the **Actions** tab and wait for "Build APK" to finish (about 5 minutes).
3. Open the finished run, download the **block-maker-apk** artifact, unzip it, and install `app-debug.apk`.
4. On your phone, allow "Install unknown apps" for your browser or Files app when asked.

## Test in a browser
Open `www/index.html` on your phone, in landscape.
