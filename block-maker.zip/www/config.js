const FB={project:'YOUR_PROJECT_ID',key:'YOUR_API_KEY'};
